import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TaxCalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 获取用户输入的收入金额
        double income = Double.parseDouble(request.getParameter("income"));

        // 计算个人所得税
        double tax = calculateIncomeTax(income);

        // 设置响应内容类型为文本
        response.setContentType("text/plain");

        // 将计算结果返回给客户端
        response.getWriter().write("TAX=" + tax);
    }

    private double calculateIncomeTax(double income) {
        // 根据中国个人所得税标准计算个人所得税
        double tax = 0.0;

        if (income <= 36000) {
            tax = income * 0.03;
        } else if (income <= 144000) {
            tax = income * 0.1 - 2520;
        } else if (income <= 300000) {
            tax = income * 0.2 - 16920;
        } else if (income <= 420000) {
            tax = income * 0.25 - 31920;
        } else if (income <= 660000) {
            tax = income * 0.3 - 52920;
        } else if (income <= 960000) {
            tax = income * 0.35 - 85920;
        } else {
            tax = income * 0.45 - 181920;
        }

        return tax;
    }
}
